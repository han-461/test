// ==UserScript==
// @namespace     https://github.com/NoName
// @name          哔哩哔哩、西瓜视频跳过接下来播放
// @author        Guapi
// @description   哔哩哔哩跳过接下来播放/西瓜视频取消自动播放
// @description:en 哔哩哔哩跳过接下来播放/西瓜视频取消自动播放
// @version       0.2
// @icon         https://i0.hdslb.com/bfs/emote/f85c354995bd99e28fc76c869bfe42ba6438eff4.png
// @include      /https?:\/\/www\.bilibili\.com\/video\/.*/
// @include      /https?:\/\/www\.ixigua\.com\/*/
// @run-at       document-end
// @license      WTFPL
// @require      https://cdn.bootcss.com/jquery/3.4.1/jquery.min.js
// ==/UserScript==

(function () {
    var jumpButton = '.bilibili-player-video-toast-item-jump';
    var xiguajumpButton = '.PlayEnding__nextVideo__cancel';
    console.log(`[${GM_info.script.name}]: 开始运行`);
    setInterval(() => {
        if($(jumpButton).length > 0) {
            $(jumpButton).trigger('click')
        };
        if($(xiguajumpButton).length > 0) {
            $(xiguajumpButton).trigger('click')
        }
    }, 100)
})();